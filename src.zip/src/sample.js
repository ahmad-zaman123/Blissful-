const productList = [
    
    {
      img: "https://shopblissfulbeauty.com/cdn/shop/files/PMskincarebundle_2f191d81-ef79-4ca4-8b9d-3f880327c642_1570x.png?v=17389041378",
      oldprice: "8,200.00",
      product_name: "PM Skincare Bundle (Dry)",
      newprice: 7020.00,
      discount: "15%",
      inStock: true
    },
    {
      img: "https://shopblissfulbeauty.com/cdn/shop/files/PM_Skincare_Bundle_Dry_Sensitive_and_Acne_Prone_Skin_d2bb4464-7e32-4ea7-8f5e-5a563583e7f5_1570x.png?v=1738904180",
      oldprice: "8,200.00",
      product_name: "PM Skincare Bundle (Oily)",
      newprice: 7020.00,
      discount: "15%",
      inStock: true
    },
    {
      img: "https://shopblissfulbeauty.com/cdn/shop/files/Mega_Bundle_Oily_and_Combination_Skin_e1d9b493-d956-4c13-86fe-9be218b407b7_1570x.jpg?v=1738904146",
      oldprice: "16,300.00",
      product_name: "Mega Bundle (Dry)",
      newprice: 13800.00,
      discount: "15%",
      inStock: true
    },
    {
      img: "https://shopblissfulbeauty.com/cdn/shop/files/Mega_Bundle_Dry_Sensitive_and_Acne_Prone_Skin_431e5ce7-4420-4d2e-9b87-35a16334a9b3_1570x.jpg?v=1738904174",
      oldprice: "16,300.00",
      product_name: "Mega Bundle (Oily)",
      newprice: 13800.00,
      discount: "15%",
      inStock: true
    },
]