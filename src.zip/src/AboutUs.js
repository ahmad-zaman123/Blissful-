import AboutUs_Container1 from "./AboutUs-Container1";
import AboutUs_info from "./AboutUs-info";

function AboutUs() {
  return (
    <>
    
    <AboutUs_Container1 />
    <br />
    <AboutUs_info />
    <br /> <br /> <br />
    </>
  );
}

export default AboutUs;
